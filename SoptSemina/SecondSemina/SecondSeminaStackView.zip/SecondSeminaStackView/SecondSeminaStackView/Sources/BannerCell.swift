//
//  BannerCell.swift
//  SecondSeminaStackView
//
//  Created by IJ . on 2019/10/26.
//  Copyright © 2019 jun. All rights reserved.
//

import UIKit

class BannerCell: UICollectionViewCell {
    
    @IBOutlet var banner: UIImageView?
    
}
