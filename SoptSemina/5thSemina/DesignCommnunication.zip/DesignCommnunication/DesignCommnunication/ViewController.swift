//
//  ViewController.swift
//  DesignCommnunication
//
//  Created by IJ . on 2019/11/16.
//  Copyright © 2019 jun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
    @IBOutlet weak var allButton: UIButton!
    @IBOutlet weak var homePremiumButton: UIButton!
    @IBOutlet weak var homeBetterButton: UIButton!
    @IBOutlet weak var homeGeneralButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        allButton.layer.cornerRadius = allButton.bounds.height / 2
        //allButton.layer.borderColor = UIColor.black.cgColor //UIColor.init(red: 218, green: 240, blue: 252, alpha: 15) as! CGColor
       //궁금증 UIColor 코드로 주기
        homePremiumButton.layer.cornerRadius = homePremiumButton.bounds.height / 2
        homeBetterButton.layer.cornerRadius = homeBetterButton.bounds.height / 2
        homeGeneralButton.layer.cornerRadius = homeGeneralButton.bounds.height / 2
        
    }
    
    

}

